# TopMart Print Agent — Windows o‘rnatish

## 0. Kerak bo‘ladi
- Windows 10/11 kompyuter
- 100×80 mm termal printer va uning Windows drayveri
- Python 3.11 yoki 3.12 (64-bit)
- Alohida Telegram bot tokeni (print-agent uchun; Railway’da ishlayotgan bot tokenini ishlatmang)
- Ruxsatli private chat/group ID
- `VEHICLE_DISTRIBUTION_BOT_KEY` qiymati (vakolatli admin Replit Secrets’dan xavfsiz ko‘chiradi; chatga yubormang)

## 1. ZIPni ochish
ZIPni masalan `C:\TopMartPrintAgent` ichiga extract qiling. Tuzilmani o‘zgartirmang: `print-agent` va `bot` papkalari yonma-yon qolishi kerak.

## 2. Python o‘rnatish
https://www.python.org/downloads/windows/ dan Python 3.11/3.12 64-bit o‘rnating. Installerda `Add python.exe to PATH` ni belgilang.
Yangi Command Prompt ochib tekshiring:

```bat
python --version
pip --version
```

## 3. Printer drayverini sozlash
Windows Settings → Bluetooth & devices → Printers & scanners → kerakli printer → Printing preferences:
- Media/Paper: 100 mm × 80 mm
- Scale: 100%
- Orientation: label dizayniga mos
- Fit/Shrink/Scale to fit: o‘chirilgan

Printer nomini aniq olish uchun PowerShell:

```powershell
Get-Printer | Select-Object -ExpandProperty Name
```

## 4. Paketlarni o‘rnatish
Command Prompt’ni Administrator sifatida oching:

```bat
cd /d C:\TopMartPrintAgent\print-agent
install.bat
```

Xatosiz tugashi kerak.

## 5. ERP bilan pairing
Pairing kodi yo‘q. Quyidagi Windows user environment qiymatlari agentni ERP va Telegram chat bilan bog‘laydi.

`<...>` joylarga real qiymatlarni shu kompyuterda kiriting; ularni chat yoki screenshotga chiqarmang:

```bat
setx TELEGRAM_BOT_TOKEN "<ALOHIDA_PRINT_AGENT_BOT_TOKEN>"
setx ALLOWED_CHAT_IDS "<PRIVATE_CHAT_YOKI_GROUP_ID>"
setx PRINTER_NAME "<GET-PRINTER_DAGI_AYNAN_NOM>"
setx API_BASE_URL "https://factory-bot-manager.replit.app/api"
setx VEHICLE_DISTRIBUTION_BOT_KEY "<REPLIT_SECRETS_DAGI_BOT_KEY>"
setx PRINT_AGENT_ID "ombor-label-1"
setx PRINT_AGENT_HEARTBEAT_SECONDS "60"
```

Bir nechta chat bo‘lsa: `123456789,-1001234567890` kabi vergul bilan ajrating.
`setx` dan keyin eski terminalni yoping va yangi Command Prompt oching.

## 6. Agentni ishga tushirish

```bat
cd /d C:\TopMartPrintAgent\print-agent
run.bat
```

Konsolda quyidagilarni tekshiring:
- `TopMart Print Agent ishga tushdi`
- printer `Mavjud printerlar` ro‘yxatida bor
- heartbeat API xatosi takrorlanmayapti
- `Telegram'dan etiketkalar kutilmoqda`

Oyna ochiq qolishi kerak.

## 7. Telegram pairing tekshiruvi
Ruxsat berilgan private chat/groupda alohida print-agent botga yuboring:

```text
/start
```

Bot javobida:
- shu chat ID;
- mavjud printerlar;
- `/vehicle_print` komandasi ko‘rinadi.

Javob kelmasa: token, bot groupga qo‘shilgani, privacy/permission va `ALLOWED_CHAT_IDS` ni tekshiring.
`Ruxsatsiz chatdan so‘rov rad etildi` bo‘lsa chat ID mos emas.

## 8. Xavfsiz test
Avval printer drayverining o‘zida 100×80 media tanlanganini yana tekshiring. Agentda lifecycle’dan alohida “dummy label test” komandasi yo‘q.

Real #8 va #9 handofflar uchun `/vehicle_print` — TEST EMAS: spool muvaffaqiyatli bo‘lsa ERP’da labelni `printed` qiladi. Shuning uchun avval faqat `/start` va heartbeat bilan pairing/healthni tekshiring.

Printer, media va heartbeat healthy ekanini ERP tomonda tasdiqlagandan keyin real birinchi bosma:

```text
/vehicle_print 8
```

Fizik natijani tekshiring:
- aynan 1 ta 100×80 label chiqdi;
- `Qop ip 100 talik` va `100 dona` mazmuni to‘g‘ri;
- barcode to‘liq, kesilmagan;
- chetlar kesilmagan va scale 100%;
- bot `1 ta 100×80 sahifa ... lifecycle tasdiqlandi` deb javob berdi.

So‘ng:

```text
/vehicle_print 9
```

Bu ham aynan 1 ta label chiqarishi va Strupa 10 dona ko‘rsatishi kerak.

## 9. Xato paytida
- `printerga topshirildi, lekin API tasdig‘i yetib bormadi`: qayta bosmang; bot aytgan `/vehicle_resume JOB_ID` ni yuboring.
- `ambiguous`: barcha sahifalar chiqqanini fizik tekshirmasdan `/vehicle_recover` ishlatmang.
- Sahifalar to‘liq chiqmagan bo‘lsa, faqat operator qaroridan keyin `/vehicle_retry JOB_ID`.
- Oddiy takroriy bosma faqat ataylab: `/vehicle_reprint HANDOFF_ID`.

## 10. Avtomatik start
`Win + R` → `shell:startup`. `C:\TopMartPrintAgent\print-agent\run.bat` uchun shortcutni shu papkaga qo‘ying.
